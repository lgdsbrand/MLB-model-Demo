# Streamlit app placeholder

import streamlit as st
st.title('MLB Betting Model')